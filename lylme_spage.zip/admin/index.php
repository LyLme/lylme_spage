<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;"  />
<title>六零导航页 - 后台管理</title>
</head>

<body>

<div align="center">
 <h2>六零导航页</h2>
   
    <table align="center" style="margin-top:30px;">

    <td><b>程序名称：</td>
    <td></b>六零导航页</td>
    </tr>
        <tr>
	<td><b>当前版本：</td>
	<td>v0.2.0-Beta</td>
	 </tr>
        <tr>
	<td><b>项目地址：</td>
	<td><a href="https://github.com/lylme/lylme_spage">Github</a></td>
	 </tr>
	 </table>
	  <p><b>注意：当前版本为开发阶段，暂无后台功能。请查看前往GitHub查看是否有更新</b></p>

</div>



</body>

</html>
